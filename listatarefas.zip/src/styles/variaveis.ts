export default {
  vermelho: '#C23616',
  verde: '#44BD32',
  amarelo: '#F0C11A',
  amarelo2: '#E1A32A',
  azulEscuro: '#2f3640'
}
