export enum TipoContato {
  PESSOAL = 'pessoal',
  PROFISSIONAL = 'profissional',
  FAMILIA = 'familia'
}

export enum StatusContato {
  ATIVO = 'ativo',
  INATIVO = 'inativo'
}
