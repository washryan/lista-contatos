export enum Prioridade {
  URGENTE = 'urgente',
  IMPORTANTE = 'importante',
  NORMAL = 'normal'
}

export enum Status {
  PENDENTE = 'pendente',
  CONCLUIDA = 'concluída'
}
