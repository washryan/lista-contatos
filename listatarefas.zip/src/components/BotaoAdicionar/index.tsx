import { Circulo } from './styles'

const BotaoAdicionar = () => <Circulo to="/contatos/novo">+</Circulo>

export default BotaoAdicionar
